import { OHLCData } from "@/lib/api/market";

// --- Interfaces ---

export interface MarketProvider {
  name: string;
  getPrice(symbol: string): Promise<number>;
  getOHLC(symbol: string, timeframe: string): Promise<OHLCData[]>;
  isHealthy(): boolean;
}

// --- Adapters ---

// 1. CoinPaprika (Primary)
class CoinPaprikaProvider implements MarketProvider {
  name = "CoinPaprika";
  private baseUrl = "https://api.coinpaprika.com/v1";
  private symbolCache = new Map<string, string>();

  private idMap: Record<string, string> = {
    'SOL': 'sol-solana',
    'BTC': 'btc-bitcoin',
    'ETH': 'eth-ethereum',
    'JUP': 'jup-jupiter',
  };

  private async resolveId(symbol: string): Promise<string | null> {
    const s = symbol.toUpperCase();
    if (this.idMap[s]) return this.idMap[s];
    if (this.symbolCache.has(s)) return this.symbolCache.get(s)!;

    try {
      const res = await fetch(`${this.baseUrl}/search?q=${s}&c=currencies&limit=1`);
      if (!res.ok) return null;
      const data = await res.json();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const coin = data.currencies?.find((c: any) => c.symbol === s);
      if (coin) {
        this.symbolCache.set(s, coin.id);
        return coin.id;
      }
    } catch (e) {
      console.warn("CoinPaprika search failed", e);
    }
    return null;
  }

  async getPrice(symbol: string): Promise<number> {
    const id = await this.resolveId(symbol);
    if (!id) throw new Error(`CoinPaprika: Symbol ${symbol} not found`);

    const res = await fetch(`${this.baseUrl}/tickers/${id}`);
    if (!res.ok) throw new Error(`CoinPaprika status ${res.status}`);
    const data = await res.json();
    return data.quotes?.USD?.price || 0;
  }

  async getOHLC(symbol: string, timeframe: string): Promise<OHLCData[]> {
    // CoinPaprika Free Tier limitations: 
    // - Only 24h history for intervals < 24h
    // - Full history only for '24h' interval
    // We try anyway, but if it fails/returns empty, the Orchestrator will skip to next provider (Binance/Moralis)
    
    const id = await this.resolveId(symbol);
    if (!id) throw new Error(`CoinPaprika: Symbol ${symbol} not found`);

    // Map timeframe to CoinPaprika limit/interval
    // Free API is very restricted on historical data. 
    // This often acts as a pass-through to fallback for Charts unless on Pro.
    const now = Math.floor(Date.now() / 1000);
    // Default to last 24h to try and get some data
    const start = now - (24 * 60 * 60); 
    
    // Attempt fetch (simplified, often fails on free for specific intervals)
    const url = `${this.baseUrl}/coins/${id}/ohlcv/historical?start=${start}&end=${now}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`CoinPaprika OHLC status ${res.status}`);
    
    const data = await res.json();
    if (!Array.isArray(data)) throw new Error("CoinPaprika invalid OHLC format");

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return data.map((d: any) => ({
      time: new Date(d.time_open).getTime() / 1000,
      open: d.open,
      high: d.high,
      low: d.low,
      close: d.close,
      volume: d.volume
    }));
  }

  isHealthy(): boolean {
    return true;
  }
}

// 2. Moralis + Binance (Fallback 1)
class MoralisBinanceProvider implements MarketProvider {
  name = "Moralis/Binance";
  private apiKey = import.meta.env.MORALIS_API_KEY || import.meta.env.VITE_MORALIS_API_KEY;
  private binanceBaseUrl = "https://api.binance.com/api/v3";

  private addressMap: Record<string, string> = {
    'SOL': 'So11111111111111111111111111111111111111112',
    'BTC': '3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh', // whBTC
    'ETH': '7vfCXTUXx5WJV5JADk1h5QqSk2E2zY7P9xJ8W2s9',     // whETH
    'JUP': 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN',
    'BONK': 'dezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263'
  };

  private binanceSymbolMap: Record<string, string> = {
    'SOL': 'SOLUSDT',
    'BTC': 'BTCUSDT',
    'ETH': 'ETHUSDT',
    'JUP': 'JUPUSDT',
    'DOGE': 'DOGEUSDT',
    'XRP': 'XRPUSDT',
    'BNB': 'BNBUSDT',
    'ADA': 'ADAUSDT',
  };

  private getAddress(symbol: string): string | null {
    return this.addressMap[symbol.toUpperCase()] || null;
  }

  private getBinancePair(symbol: string): string {
    const s = symbol.toUpperCase();
    return this.binanceSymbolMap[s] || `${s}USDT`;
  }

  async getPrice(symbol: string): Promise<number> {
    if (!this.apiKey) throw new Error("Moralis API Key missing");
    
    const address = this.getAddress(symbol);
    // If no address mapped, we might fail or try a search if Moralis supports it (it generally doesn't for symbols on solana endpoint easily).
    // For now, throw if not found to trigger next fallback? Or define more map entries.
    if (!address) throw new Error(`Moralis: No address mapped for ${symbol}`);

    const url = `https://solana-gateway.moralis.io/token/mainnet/${address}/price`;
    
    const res = await fetch(url, {
      headers: {
        'X-API-Key': this.apiKey
      }
    });
    
    if (!res.ok) throw new Error(`Moralis status ${res.status}`);
    const data = await res.json();
    return data.usdPrice || 0;
  }

  async getOHLC(symbol: string, timeframe: string): Promise<OHLCData[]> {
    // Reuse Binance logic
    const pair = this.getBinancePair(symbol);
    const interval = timeframe.toLowerCase(); 
    const limit = 100;
    const url = `${this.binanceBaseUrl}/klines?symbol=${pair}&interval=${interval}&limit=${limit}`;
    
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Binance status ${res.status}`);
    
    const data = await res.json();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return data.map((d: any) => ({
      time: d[0] / 1000,
      open: parseFloat(d[1]),
      high: parseFloat(d[2]),
      low: parseFloat(d[3]),
      close: parseFloat(d[4]),
      volume: parseFloat(d[5]),
    }));
  }

  isHealthy(): boolean {
    return !!this.apiKey;
  }
}

// 4. CoinCap (Fallback 3)
class CoinCapProvider implements MarketProvider {
  name = "CoinCap";
  private baseUrl = "https://api.coincap.io/v2";
  private symbolCache = new Map<string, string>();

  private idMap: Record<string, string> = {
    'SOL': 'solana',
    'BTC': 'bitcoin',
    'ETH': 'ethereum',
  };

  private async resolveId(symbol: string): Promise<string | null> {
    const s = symbol.toUpperCase();
    if (this.idMap[s]) return this.idMap[s];
    if (this.symbolCache.has(s)) return this.symbolCache.get(s)!;

    try {
      const res = await fetch(`${this.baseUrl}/assets?search=${s}`);
      if (!res.ok) return null;
      const json = await res.json();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const coin = json.data?.find((c: any) => c.symbol === s);
      if (coin) {
        this.symbolCache.set(s, coin.id);
        return coin.id;
      }
    } catch (e) {
      console.warn("CoinCap search failed", e);
    }
    return null;
  }

  async getPrice(symbol: string): Promise<number> {
    const id = await this.resolveId(symbol);
    if (!id) throw new Error(`CoinCap: Symbol ${symbol} not found`);
    
    const res = await fetch(`${this.baseUrl}/assets/${id}`);
    if (!res.ok) throw new Error(`CoinCap status ${res.status}`);
    const json = await res.json();
    return parseFloat(json.data.priceUsd);
  }

  async getOHLC(symbol: string, timeframe: string): Promise<OHLCData[]> {
    const id = await this.resolveId(symbol);
    if (!id) throw new Error(`CoinCap: Symbol ${symbol} not found`);

    const mappedInterval = this.mapTimeframe(timeframe);
    
    // CoinCap candles require exchange. 'binance' is a good default try.
    // If id is known, we can try to fetch candles.
    const url = `${this.baseUrl}/candles?exchange=binance&interval=${mappedInterval}&baseId=${id}&quoteId=tether`;
    
    const res = await fetch(url);
    if (!res.ok) throw new Error(`CoinCap candles status ${res.status}`);
    const json = await res.json();
    
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return json.data.map((d: any) => ({
      time: d.period / 1000,
      open: parseFloat(d.open),
      high: parseFloat(d.high),
      low: parseFloat(d.low),
      close: parseFloat(d.close),
      volume: parseFloat(d.volume),
    }));
  }
  
  private mapTimeframe(tf: string): string {
      if (tf.endsWith('m')) return `m${tf.replace('m','')}`;
      if (tf.endsWith('h')) return `h${tf.replace('h','')}`;
      if (tf.endsWith('d')) return `d${tf.replace('d','')}`;
      return 'h1';
  }

  isHealthy(): boolean {
    return true;
  }
}

// Removed old Moralis stub, integrated into list below
// --- Orchestrator ---

export class MarketOrchestrator {
  private providers: MarketProvider[] = [];

  constructor() {
    this.providers = [
      new CoinPaprikaProvider(),
      new MoralisBinanceProvider(),
      new CoinCapProvider(),
    ];
  }

  async getPrice(symbol: string): Promise<number> {
    const errors: string[] = [];
    
    for (const provider of this.providers) {
      try {
        const price = await provider.getPrice(symbol);
        if (price > 0) return price;
      } catch (err) {
        errors.push(`${provider.name}: ${(err as Error).message}`);
        // console.warn(`Fallback: ${provider.name} failed for ${symbol}`, err);
      }
    }
    
    console.error("All providers failed for price:", errors);
    throw new Error("All market providers failed");
  }

  async getOHLC(symbol: string, timeframe: string): Promise<OHLCData[]> {
    const errors: string[] = [];

    for (const provider of this.providers) {
      try {
        const data = await provider.getOHLC(symbol, timeframe);
        if (data.length > 0) return data;
      } catch (err) {
        errors.push(`${provider.name}: ${(err as Error).message}`);
        console.warn(`Fallback: ${provider.name} failed for OHLC ${symbol}`, err);
      }
    }

    console.error("All providers failed for OHLC:", errors);
    return []; // Return empty array instead of throwing to avoid crashing UI completely
  }
}

export const marketOrchestrator = new MarketOrchestrator();
