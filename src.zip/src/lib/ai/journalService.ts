// src/lib/ai/journalService.ts

export interface AiJournalContext {
  emotionalState: string;
  confidence: number;
  conviction: number;
  patternQuality: number;
  reasoning: string;
}

export interface AiJournalResponse {
  notes: string;
  suggestions?: string[];
}

/**
 * Service to handle AI generation for journal entries.
 * Currently returns a mock response, but structured to easily swap with a real API call.
 */
export async function generateJournalNotes(context: AiJournalContext): Promise<AiJournalResponse> {
  // TODO: Replace with actual API call to backend/edge function
  // e.g., return await fetch('/api/ai/journal-notes', { method: 'POST', body: JSON.stringify(context) });

  console.log("Generating AI notes with context:", context);

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1500));

  // Determine tone based on emotional state
  const isHighConfidence = context.confidence > 70;
  const isEmotional = ["revenge", "fomo", "fear"].includes(context.emotionalState.toLowerCase());

  let note = `Based on your ${context.emotionalState} state with ${context.confidence}% confidence:\n\n`;

  if (isEmotional) {
    note += `⚠️ **Risk Alert:** You are trading under emotional influence. Consider stepping back.\n`;
    note += `- Review your invalidation level strictly.\n`;
    note += `- Are you chasing a loss? Verify your setup criteria twice.\n`;
  } else if (isHighConfidence) {
    note += `✅ **Strong Conviction:** Setup looks solid. Ensure position sizing aligns with your risk model.\n`;
    note += `- Focus on execution quality.\n`;
    note += `- Document your take-profit targets clearly.\n`;
  } else {
    note += `ℹ️ **Observation Mode:** Confidence is moderate. Good for smaller size or paper trading.\n`;
    note += `- What additional confirmation are you waiting for?\n`;
  }

  return {
    notes: note,
    suggestions: ["Check higher timeframe bias", "Verify news calendar"],
  };
}

