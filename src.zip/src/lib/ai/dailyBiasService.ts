import { marketApi, OHLCData } from "@/lib/api/market";
import { computeDailyBiasSignal } from "@/features/dailyBias/signalCore";
import { formatDailyBiasNarration } from "@/features/dailyBias/narration";
import { MarketData, DailyBiasSignal, DailyBiasNarration } from "@/features/dailyBias/types";

// Cache structure
interface CacheItem {
  signal: DailyBiasSignal;
  narration: DailyBiasNarration;
  timestamp: number;
}

const CACHE_TTL = 30 * 60 * 1000; // 30 minutes (client-side cache)
const cache = new Map<string, CacheItem>();

async function fetchMarketData(symbol: string, timeframe: string): Promise<MarketData> {
  const ohlcData = await marketApi.getOHLC(symbol, timeframe);
  const candles = ohlcData.map(c => ({
    ts: c.time * 1000,
    open: c.open,
    high: c.high,
    low: c.low,
    close: c.close,
    volume: c.volume
  }));
  
  // Use last candle close or fetch current price if no candles
  let lastPrice = 0;
  if (candles.length > 0) {
    lastPrice = candles[candles.length - 1].close;
  } else {
    lastPrice = await marketApi.getPrice(symbol);
  }

  return {
    symbol,
    timeframe,
    candles,
    lastPrice,
    source: "Binance+CoinGecko",
    fetchedAt: Date.now(),
  };
}

export async function analyzeMarketDailyBias(symbol: string, timeframe: string = "15m"): Promise<{ signal: DailyBiasSignal; narration: DailyBiasNarration }> {
  const cacheKey = `${symbol}:${timeframe}`;
  const now = Date.now();
  const cached = cache.get(cacheKey);

  // Return cached if valid and same day (approximately) or within TTL
  // The spec mentions "dailyKey". Here we use TTL + simplistic daily check if needed.
  // For MVP, simple TTL is fine, but let's respect the "daily bias" nature.
  // Ideally, we refresh if it's stale or if the "day" has changed.
  // But markets are 24/7, so "daily" often means rolling 24h.
  if (cached && (now - cached.timestamp < CACHE_TTL)) {
    return { signal: cached.signal, narration: cached.narration };
  }

  const data = await fetchMarketData(symbol, timeframe);

  const expectedCandles = timeframe === "1h" ? 24 : 96;

  const signal = computeDailyBiasSignal(data, {
    windowHours: 24,
    expectedCandles,
  });

  const narration = formatDailyBiasNarration(signal);

  // Update cache
  cache.set(cacheKey, { signal, narration, timestamp: now });

  return { signal, narration };
}

