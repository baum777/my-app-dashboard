// src/lib/grokPulse/contextBuilder.ts
import type { PulseGlobalToken } from "./types";

export const buildContextPrompt = (token: PulseGlobalToken, recentTweets?: string[]): string => {
  const lines: string[] = [];

  lines.push(`Token: $${token.symbol.toUpperCase()} (${token.address.slice(0, 8)}...${token.address.slice(-4)})`);

  if (token.ageMinutes !== undefined) {
    lines.push(
      token.ageMinutes < 40
        ? `Phase: Neu auf pump.fun (${token.ageMinutes} Min alt)`
        : token.migratedToRaydium
          ? `Phase: Migriert zu Raydium`
          : `Phase: Auf Raydium`,
    );
  }

  if (token.marketCap) lines.push(`Market Cap: $${(token.marketCap / 1e6).toFixed(1)}M`);
  if (token.priceChange24h)
    lines.push(`24h Change: ${token.priceChange24h > 0 ? "+" : ""}${token.priceChange24h.toFixed(1)}%`);

  if (recentTweets && recentTweets.length > 0) {
    lines.push(`\nAktuelle CT-Stimmen (letzte 2h):`);
    recentTweets.slice(0, 5).forEach((t) => lines.push(`• "${t}"`));
  } else {
    lines.push(`\nCT bisher ruhig – keine starke Diskussion in den letzten 2 Stunden.`);
  }

  lines.push(`\nAnalysiere NUR die letzten 2 Stunden CT und gib mir dein aktuelles Sentiment.`);

  return lines.join("\n");
};
