// src/lib/grokPulse/__mocks__/@vercel/kv.ts
// Minimal in-memory mock compatible with used Redis commands.

type Store = Map<string, string>;
const store: Store = new Map();

const expires: Map<string, number> = new Map();

const isExpired = (key: string) => {
  const t = expires.get(key);
  if (!t) return false;
  if (Date.now() > t) {
    store.delete(key);
    expires.delete(key);
    return true;
  }
  return false;
};

export const kv = {
  async get<T = unknown>(key: string): Promise<T | null> {
    if (isExpired(key)) return null;
    const value = store.get(key);
    if (!value) return null;
    // Don't auto-parse JSON, behave like raw Redis string get if that's what's stored
    return value as unknown as T;
  },

  async set(key: string, value: string, opts?: { ex?: number }) {
    store.set(key, value);
    if (opts?.ex) expires.set(key, Date.now() + opts.ex * 1000);
  },

  async incr(key: string) {
    if (isExpired(key)) {
      // already removed
    }
    const cur = Number(store.get(key) || 0);
    const next = cur + 1;
    store.set(key, String(next));
    return next;
  },

  async expire(key: string, seconds: number) {
    expires.set(key, Date.now() + seconds * 1000);
  },

  async lpush(key: string, value: string) {
    const raw = store.get(key);
    const arr = raw ? (JSON.parse(raw) as string[]) : [];
    arr.unshift(value);
    store.set(key, JSON.stringify(arr));
    return arr.length;
  },

  async ltrim(key: string, start: number, stop: number) {
    const raw = store.get(key);
    const arr = raw ? (JSON.parse(raw) as string[]) : [];
    const trimmed = arr.slice(start, stop + 1);
    store.set(key, JSON.stringify(trimmed));
  },

  _reset() {
    store.clear();
    expires.clear();
  },
};
