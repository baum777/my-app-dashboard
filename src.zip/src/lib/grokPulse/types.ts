// src/lib/grokPulse/types.ts
export enum SentimentLabel {
  MOON = "MOON",
  STRONG_BULL = "STRONG_BULL",
  BULL = "BULL",
  NEUTRAL = "NEUTRAL",
  BEAR = "BEAR",
  STRONG_BEAR = "STRONG_BEAR",
  RUG = "RUG",
  DEAD = "DEAD",
}

export enum CallToAction {
  APE = "APE",
  DCA = "DCA",
  WATCH = "WATCH",
  DUMP = "DUMP",
  AVOID = "AVOID",
}

export interface GrokSentimentSnapshot {
  score: number; // -100 to +100
  label: SentimentLabel;
  confidence: number; // 0-100
  cta: CallToAction;
  one_liner: string;
  top_snippet: string;
  validation_hash: string;
  ts: number;
  delta?: number;
  low_confidence?: boolean;
  source: "grok" | "fallback";
}

export interface PulseGlobalToken {
  address: string;
  symbol: string;
  chain: "solana";
  marketCap?: number;
  priceChange24h?: number;
  volume24h?: number;
  ageMinutes?: number;
  migratedToRaydium?: boolean;
}

export interface PulseMetaLastRun {
  ts: number;
  success: number;
  failed: number;
  total: number;
  tokensProcessed: number;
}

export interface PulseRunResult {
  token: PulseGlobalToken;
  snapshot: GrokSentimentSnapshot;
}

