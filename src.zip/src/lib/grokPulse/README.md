# Grok Pulse (final files bundle)

This bundle contains a production-safe Grok Pulse Engine for a Next.js (App Router) + Vercel KV stack.

## Files
- src/lib/grokPulse/*: engine, kv layer, grok client, context builder, sources, fallback
- app/api/grok-pulse/route.ts: cron-triggered API route (POST) + health (GET)
- tests: vitest-based unit tests + @vercel/kv mock

## Env
- GROK_API_KEY
- PULSE_CRON_SECRET
- MAX_DAILY_GROK_CALLS (optional, default 900)

## Notes
- Quota is tracked as *attempts* (budget relevant) and *success* (telemetry).
- History uses Redis list ops (LPUSH/LTRIM/EXPIRE) to avoid race conditions.

