// src/lib/grokPulse/__tests__/grokClient.test.ts
import { describe, it, expect, vi } from "vitest";
import { callGrok } from "../grokClient";

describe("grokClient", () => {
  it("returns null on fetch failure", async () => {
    const old = globalThis.fetch;
    globalThis.fetch = vi.fn(async () => ({ ok: false } as Response)) as unknown as typeof fetch;
    const r = await callGrok("x");
    expect(r).toBe(null);
    globalThis.fetch = old;
  });
});

