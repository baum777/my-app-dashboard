// src/lib/grokPulse/__tests__/kv.test.ts
import { describe, it, expect, beforeEach, vi } from "vitest";
import { kv } from "@vercel/kv";
import {
  appendHistory,
  getCurrentSnapshot,
  getGlobalTokenListFromKV,
  getPulseMetaLastRun,
  incrDailyAttempt,
  setCurrentSnapshot,
  setGlobalTokenList,
  setPulseMetaLastRun,
} from "../kv";
import { SentimentLabel, CallToAction } from "../types";

vi.mock("@vercel/kv", async () => {
  return await vi.importActual("../__mocks__/@vercel/kv");
});

interface MockKV {
  _reset: () => void;
}

beforeEach(() => {
  (kv as unknown as MockKV)._reset();
});

describe("kv", () => {
  it("stores and reads snapshot", async () => {
    await setCurrentSnapshot("abc", {
      score: 0,
      label: SentimentLabel.NEUTRAL,
      confidence: 10,
      cta: CallToAction.WATCH,
      one_liner: "x",
      top_snippet: "",
      validation_hash: "h",
      ts: 1,
      source: "fallback",
    });

    const got = await getCurrentSnapshot("abc");
    expect(got?.score).toBe(0);
  });

  it("tracks attempts", async () => {
    const a1 = await incrDailyAttempt();
    const a2 = await incrDailyAttempt();
    expect(a1).toBe(1);
    expect(a2).toBe(2);
  });

  it("stores global list", async () => {
    await setGlobalTokenList([{ chain: "solana", address: "a", symbol: "A" }]);
    const got = await getGlobalTokenListFromKV();
    expect(got?.[0].address).toBe("a");
  });

  it("stores last run", async () => {
    await setPulseMetaLastRun({ ts: 1, success: 1, failed: 0, total: 1, tokensProcessed: 1 });
    const got = await getPulseMetaLastRun();
    expect(got?.success).toBe(1);
  });

  it("appends history", async () => {
    await appendHistory("a", { ts: 1, score: 10 });
    await appendHistory("a", { ts: 2, score: 20 });
    // history stored as JSON list inside mock; just ensure no throw.
    expect(true).toBe(true);
  });
});

