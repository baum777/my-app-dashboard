// src/lib/grokPulse/__tests__/engine.test.ts
import { describe, it, expect, beforeEach, vi } from "vitest";
import { kv } from "@vercel/kv";
import { runGrokPulse } from "../engine";

vi.mock("@vercel/kv", async () => {
  return await vi.importActual("../__mocks__/@vercel/kv");
});

beforeEach(() => {
  (kv as unknown as { _reset: () => void })._reset();
});

describe("engine", () => {
  it("runs without throwing", async () => {
    const old = globalThis.fetch;
    globalThis.fetch = vi.fn(async () => ({ ok: false } as Response)) as unknown as typeof fetch;

    const r = await runGrokPulse();
    expect(r.meta.tokensProcessed).toBeGreaterThanOrEqual(0);

    globalThis.fetch = old;
  });
});

