// src/lib/grokPulse/grokClient.ts
import crypto from "crypto";
import type { GrokSentimentSnapshot, SentimentLabel, CallToAction } from "./types";

const SYSTEM_PROMPT =
  "Du bist ein präziser Solana-CT-Sentiment-Analyst. Antworte AUSSCHLIESSLICH mit gültigem JSON im exakten Format. Kein Markdown, keine Erklärung.";

export const callGrok = async (userPrompt: string): Promise<GrokSentimentSnapshot | null> => {
  try {
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.GROK_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "grok-beta",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 300,
      }),
    });

    if (!res.ok) return null;

    const data = await res.json();
    const content = data.choices?.[0]?.message?.content?.trim();

    if (!content) return null;

    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch {
      return null;
    }

    // Range + Integrity Validation
    interface ParsedResponse {
      score: number;
      confidence: number;
      validation_hash: string;
      label?: string;
      cta?: string;
      one_liner?: string;
      top_snippet?: string;
      delta?: number;
      low_confidence?: boolean;
    }
    
    const parsedTyped = parsed as ParsedResponse;
    
    if (
      typeof parsedTyped.score !== "number" ||
      parsedTyped.score < -100 ||
      parsedTyped.score > 100 ||
      typeof parsedTyped.confidence !== "number" ||
      parsedTyped.confidence < 0 ||
      parsedTyped.confidence > 100
    )
      return null;

    const { validation_hash, ...withoutHash } = parsedTyped;
    const hash = crypto.createHash("sha256").update(JSON.stringify(withoutHash)).digest("hex");

    if (hash !== validation_hash) return null;

    return {
      ...parsedTyped,
      ts: Date.now(),
      source: "grok" as const,
    } as GrokSentimentSnapshot;
  } catch {
    return null;
  }
};

