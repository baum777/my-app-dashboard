// src/lib/grokPulse/sources/index.ts
import type { PulseGlobalToken } from "../types";
import { getGlobalTokenListFromKV, setGlobalTokenList } from "../kv";

const SEED: PulseGlobalToken[] = [
  {
    chain: "solana",
    address: "So11111111111111111111111111111111111111112",
    symbol: "SOL",
  },
];

export const getGlobalTokenList = async (): Promise<PulseGlobalToken[]> => {
  const cached = await getGlobalTokenListFromKV();
  if (cached && cached.length) return cached;

  // TODO: replace with DexScreener/Birdeye trending fetch.
  await setGlobalTokenList(SEED);
  return SEED;
};

