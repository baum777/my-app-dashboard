// src/lib/grokPulse/telemetry.ts
import type { PulseEvent } from "./events";

export const emitPulseEvent = async (_evt: PulseEvent): Promise<void> => {
  // Intentionally minimal: wire this to your analytics/log pipeline later.
  // Keep engine behavior deterministic and non-blocking.
  return;
};

