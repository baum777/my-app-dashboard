// src/lib/grokPulse/kv.ts
import { kv as vercelKv } from "@vercel/kv";
import type { GrokSentimentSnapshot, PulseGlobalToken, PulseMetaLastRun } from "./types";

const PREFIX = "grokPulse";

const KEYS = {
  snapshot: (addr: string) => `${PREFIX}:snapshot:${addr}`,
  history: (addr: string) => `${PREFIX}:history:${addr}`,
  globalList: () => `${PREFIX}:tokens:list`,
  lastRun: () => `${PREFIX}:meta:lastRun`,
  usageAttempts: (date: string) => `${PREFIX}:usage:attempts:${date}`,
  usageSuccess: (date: string) => `${PREFIX}:usage:success:${date}`,
};

const TTL = {
  SNAPSHOT: 45 * 60, // 45 min
  HISTORY: 7 * 24 * 60 * 60, // 7d
  GLOBAL_LIST: 15 * 60, // 15m
};

// Type augmentation for Vercel KV to include Redis commands if missing in the type view
type KVPlus = typeof vercelKv & {
  incr: (key: string) => Promise<number>;
  expire: (key: string, seconds: number) => Promise<number>;
  lpush: (key: string, ...values: unknown[]) => Promise<number>;
  ltrim: (key: string, start: number, stop: number) => Promise<void>;
  set: (key: string, value: unknown, opts?: { ex?: number; nx?: boolean }) => Promise<string | null>;
  get: <T>(key: string) => Promise<T | null>;
};

export const kv = vercelKv as KVPlus;

const today = () => new Date().toISOString().slice(0, 10);

export const incrDailyAttempt = async () => {
  const key = KEYS.usageAttempts(today());
  const n = await kv.incr(key);
  await kv.expire(key, 24 * 60 * 60);
  return n;
};

export const incrDailySuccess = async () => {
  const key = KEYS.usageSuccess(today());
  const n = await kv.incr(key);
  await kv.expire(key, 24 * 60 * 60);
  return n;
};

export const setCurrentSnapshot = async (address: string, snap: GrokSentimentSnapshot) => {
  await kv.set(KEYS.snapshot(address), JSON.stringify(snap), { ex: TTL.SNAPSHOT });
};

export const getCurrentSnapshot = async (address: string): Promise<GrokSentimentSnapshot | null> => {
  const raw = await kv.get<string>(KEYS.snapshot(address));
  return raw ? (JSON.parse(raw) as GrokSentimentSnapshot) : null;
};

export const appendHistory = async (address: string, entry: { ts: number; score: number }) => {
  await kv.lpush(KEYS.history(address), JSON.stringify(entry));
  await kv.ltrim(KEYS.history(address), 0, 49);
  await kv.expire(KEYS.history(address), TTL.HISTORY);
};

export const setGlobalTokenList = async (tokens: PulseGlobalToken[]) => {
  await kv.set(KEYS.globalList(), JSON.stringify(tokens), { ex: TTL.GLOBAL_LIST });
};

export const getGlobalTokenListFromKV = async (): Promise<PulseGlobalToken[] | null> => {
  const raw = await kv.get<string>(KEYS.globalList());
  return raw ? (JSON.parse(raw) as PulseGlobalToken[]) : null;
};

export const setPulseMetaLastRun = async (meta: PulseMetaLastRun) => {
  await kv.set(KEYS.lastRun(), JSON.stringify(meta));
};

export const getPulseMetaLastRun = async (): Promise<PulseMetaLastRun | null> => {
  const raw = await kv.get<string>(KEYS.lastRun());
  return raw ? (JSON.parse(raw) as PulseMetaLastRun) : null;
};

export const getKeys = () => KEYS;
