// src/lib/grokPulse/events.ts
export type PulseEventName =
  | "pulse_run_started"
  | "pulse_run_finished"
  | "pulse_token_processed"
  | "pulse_token_failed"
  | "pulse_quota_reached";

export interface PulseEvent {
  name: PulseEventName;
  ts: number;
  meta?: Record<string, unknown>;
}

