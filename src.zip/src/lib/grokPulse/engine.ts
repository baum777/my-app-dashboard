// src/lib/grokPulse/engine.ts
import { buildContextPrompt } from "./contextBuilder";
import { callGrok } from "./grokClient";
import { calculateKeywordFallback } from "./fallback-sentiment";
import { getGlobalTokenList } from "./sources/index";
import type { GrokSentimentSnapshot, PulseRunResult, PulseMetaLastRun, PulseGlobalToken } from "./types";
import {
  appendHistory,
  getCurrentSnapshot,
  incrDailyAttempt,
  incrDailySuccess,
  setCurrentSnapshot,
  setPulseMetaLastRun,
} from "./kv";
import { emitPulseEvent } from "./telemetry";

const MAX_BATCH = 30;

const quotaReached = (attemptCount: number) => {
  const max = Number(process.env.MAX_DAILY_GROK_CALLS) || 900;
  return attemptCount > max;
};

const processToken = async (token: PulseGlobalToken): Promise<PulseRunResult> => {
  const old = await getCurrentSnapshot(token.address);
  const context = buildContextPrompt(token);

  const result = await callGrok(context);
  const snapshot: GrokSentimentSnapshot = result || calculateKeywordFallback([], token);

  if (!result) {
    snapshot.low_confidence = true;
    snapshot.source = "fallback";
  }

  if (old) snapshot.delta = snapshot.score - old.score;

  await setCurrentSnapshot(token.address, snapshot);
  await appendHistory(token.address, { ts: Date.now(), score: snapshot.score });

  return { token, snapshot };
};

export const runGrokPulse = async (): Promise<{ meta: PulseMetaLastRun; results: PulseRunResult[] }> => {
  const started = Date.now();
  await emitPulseEvent({ name: "pulse_run_started", ts: started });

  const attemptCount = await incrDailyAttempt();
  if (quotaReached(attemptCount)) {
    await emitPulseEvent({ name: "pulse_quota_reached", ts: Date.now(), meta: { attemptCount } });
    const meta: PulseMetaLastRun = {
      ts: Date.now(),
      success: 0,
      failed: 0,
      total: 0,
      tokensProcessed: 0,
    };
    await setPulseMetaLastRun(meta);
    await emitPulseEvent({ name: "pulse_run_finished", ts: Date.now(), meta: { ms: Date.now() - started } });
    return { meta, results: [] };
  }

  const tokens = await getGlobalTokenList();
  const batch = tokens.slice(0, MAX_BATCH);

  let success = 0;
  let failed = 0;
  const results: PulseRunResult[] = [];

  await Promise.all(
    batch.map(async (token) => {
      try {
        const r = await processToken(token);
        results.push(r);
        success++;
        await incrDailySuccess();
        await emitPulseEvent({
          name: "pulse_token_processed",
          ts: Date.now(),
          meta: { address: token.address, score: r.snapshot.score },
        });
      } catch (e) {
        failed++;
        await emitPulseEvent({
          name: "pulse_token_failed",
          ts: Date.now(),
          meta: { address: token.address, error: (e as Error)?.message ?? "unknown" },
        });
      }
    }),
  );

  const meta: PulseMetaLastRun = {
    ts: Date.now(),
    success,
    failed,
    total: success + failed,
    tokensProcessed: batch.length,
  };

  await setPulseMetaLastRun(meta);
  await emitPulseEvent({ name: "pulse_run_finished", ts: Date.now(), meta: { ms: Date.now() - started } });

  return { meta, results };
};

