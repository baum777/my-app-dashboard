// src/lib/grokPulse/fallback-sentiment.ts
import crypto from "crypto";
import {
  CallToAction,
  SentimentLabel,
  type GrokSentimentSnapshot,
  type PulseGlobalToken,
} from "./types";

export const calculateKeywordFallback = (
  recentTweets: string[],
  _token: PulseGlobalToken,
): GrokSentimentSnapshot => {
  const text = recentTweets.join("\n").toLowerCase();

  const hasRug = /(rug|scam|honeypot|drainer|hack|exploit)/.test(text);
  const hasBull = /(moon|send|bull|breakout|pump|up only)/.test(text);

  const base = {
    score: hasRug ? -70 : hasBull ? 35 : 0,
    label: hasRug ? SentimentLabel.RUG : hasBull ? SentimentLabel.BULL : SentimentLabel.NEUTRAL,
    confidence: hasRug ? 55 : hasBull ? 40 : 25,
    cta: hasRug ? CallToAction.AVOID : CallToAction.WATCH,
    one_liner: hasRug
      ? "High risk signals detected (fallback)."
      : hasBull
        ? "Mild bullish chatter detected (fallback)."
        : "No strong chatter detected (fallback).",
    top_snippet: recentTweets[0] || "",
  };

  const validation_hash = crypto
    .createHash("sha256")
    .update(JSON.stringify(base))
    .digest("hex");

  return {
    ...base,
    validation_hash,
    ts: Date.now(),
    source: "fallback",
    low_confidence: true,
  };
};

