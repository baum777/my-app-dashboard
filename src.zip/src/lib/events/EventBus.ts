import { ConfirmedEntry } from "@/features/journal/types";

// Define payloads for events
export type EventPayloads = {
  // Journal
  "JOURNAL_ENTRY_CONFIRMED": ConfirmedEntry;
  "FULL_EXIT": { entryId: string; pnl: number; symbol: string };
  
  // Replay
  "REPLAY_STARTED": { symbol: string; timeframe: string };
  "REPLAY_TRADE_PLACED": { symbol: string; pnl?: number };

  // Alerts
  "ALERT_CREATED": { symbol: string; condition: string };
  "ALERT_ACKNOWLEDGED": { alertId: string };
  
  // Generic/Testing
  "TEST_EVENT": { value: number };
};

export type EventType = keyof EventPayloads;

export interface BusEvent<T extends EventType> {
  id: string; // UUID
  ts: number; // Timestamp
  type: T;
  payload: EventPayloads[T];
}

type Handler<T extends EventType> = (event: BusEvent<T>) => void;

class EventBus {
  private handlers: Partial<Record<EventType, Set<Handler<EventType>>>> = {};

  on<T extends EventType>(type: T, handler: Handler<T>) {
    if (!this.handlers[type]) {
      this.handlers[type] = new Set();
    }
    this.handlers[type]!.add(handler);
    return () => this.off(type, handler);
  }

  off<T extends EventType>(type: T, handler: Handler<T>) {
    this.handlers[type]?.delete(handler);
  }

  emit<T extends EventType>(type: T, payload: EventPayloads[T]) {
    const event: BusEvent<T> = {
      id: crypto.randomUUID(),
      ts: Date.now(),
      type,
      payload
    };

    const handlers = this.handlers[type];
    if (handlers) {
      handlers.forEach(h => {
        try {
          h(event);
        } catch (e) {
          console.error(`Error in EventBus handler for ${type}:`, e);
        }
      });
    }
  }
}

export const eventBus = new EventBus();

