import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import {
  DashboardHeader,
  DailyBiasCard,
  HoldingsCard,
  LastTradesCard,
  InsightCard,
  JournalSnapshotCard,
  AlertsSnapshotCard,
  DashboardEmptyState,
  DashboardFab,
  DashboardKpiCards,
  RecentEntriesCard,
} from "@/components/dashboard";
import { useTradesStore } from "@/features/journal/useTradesStore";
import { useJournalStore } from "@/features/journal/useJournalStore";
import { useAlerts } from "@/features/alerts";

export default function Dashboard() {
  const navigate = useNavigate();
  const { hasTrades, trades } = useTradesStore();
  const { confirmedEntries, pendingCount } = useJournalStore();
  const { alerts } = useAlerts();
  const [isRefreshingBias, setIsRefreshingBias] = useState(false);
  
  const triggeredAlerts = alerts.filter(a => a.status === 'triggered').length;

  // Calculate KPIs
  const kpiData = useMemo(() => {
    // Combine manual trades with confirmed journal entries for a holistic view
    // Note: This assumes `trades` (legacy/manual) and `confirmedEntries` (journal) are distinct or need unification.
    // For this implementation, we prioritize `confirmedEntries` if available, or fallback to `trades`.
    // Ideally, `useTradesStore` should eventually read from `confirmedEntries`.
    
    // For now, let's treat `confirmedEntries` as the source of truth for "Journal" stats
    // and `trades` as the source for legacy PnL until migrated.
    
    // Simple logic: If we have confirmed journal entries, use them for stats.
    const activeSource = confirmedEntries.length > 0 ? confirmedEntries : trades;
    
    if (activeSource.length === 0) {
      return { 
        netPnl: 0, 
        netPnlPercent: 0, 
        winRate30d: 0, 
        todayTxs: 0, 
        todayAmount: 0,
        journalStreak: 0,
        tradeInboxCount: pendingCount,
      };
    }

    // Adapt types: ConfirmedEntry doesn't strictly match Trade interface for PnL
    // We need to extract PnL from ConfirmedEntry if using it.
    // ConfirmedEntry has `pnl: PnLInfo` { realizedUsd, ... }
    // Trade has `pnl: string`
    
    let netPnl = 0;
    let winCount = 0;
    let lossCount = 0;
    let todayTxs = 0;
    let todayAmount = 0;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (confirmedEntries.length > 0) {
        // Use Journal V2 Data
        confirmedEntries.forEach(e => {
            const pnl = e.pnl?.realizedUsd || 0;
            netPnl += pnl;
            if (pnl > 0) winCount++;
            if (pnl < 0) lossCount++;
            
            if (new Date(e.createdAt) >= today) {
                todayTxs++;
                todayAmount += pnl;
            }
        });
    } else {
        // Fallback to Legacy Trades
        trades.forEach(t => {
            const pnl = parseFloat(t.pnl || "0");
            if (pnl !== 0) {
                netPnl += pnl;
                if (pnl > 0) winCount++;
                if (pnl < 0) lossCount++;
            }
            if (new Date(t.createdAt) >= today) {
                todayTxs++;
                todayAmount += pnl;
            }
        });
    }

    const totalClosed = winCount + lossCount;
    const winRate = totalClosed > 0 ? (winCount / totalClosed) * 100 : 0;
    
    // Mock for streak/percent until portfolio module is ready
    return {
      netPnl,
      netPnlPercent: 0, // Needs Portfolio Value
      winRate30d: winRate,
      todayTxs,
      todayAmount,
      journalStreak: 0, // Needs calendar logic
      tradeInboxCount: pendingCount,
    };
  }, [trades, confirmedEntries, pendingCount]);

  // Journal snapshot data
  const journalData = useMemo(() => {
    const activeSource = confirmedEntries.length > 0 ? confirmedEntries : trades;
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const thisWeekEntries = activeSource.filter(t => new Date(t.createdAt) >= weekAgo);
    const lastEntry = activeSource[0]; // Assumes sorted desc
    
    return {
      totalEntries: activeSource.length,
      thisWeekEntries: thisWeekEntries.length,
      lastEntryDate: lastEntry 
        ? formatDistanceToNow(new Date(lastEntry.createdAt), { addSuffix: true })
        : undefined,
    };
  }, [trades, confirmedEntries]);

  const handleLogEntry = () => {
    navigate("/journal");
  };

  const handleCreateAlert = () => {
    navigate("/alerts");
  };

  const handleRefreshBias = () => {
    setIsRefreshingBias(true);
    setTimeout(() => setIsRefreshingBias(false), 1500);
  };

  const handleViewJournal = () => {
    navigate("/journal");
  };

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6" data-testid="page-dashboard">
      {/* Header with meta counters and primary CTA */}
      <DashboardHeader 
        entriesCount={trades.length}
        alertsCount={alerts.length}
        onLogEntry={handleLogEntry}
      />

      {/* 5 Horizontal KPI Cards */}
      <DashboardKpiCards
        netPnl={kpiData.netPnl}
        netPnlPercent={kpiData.netPnlPercent}
        winRate30d={kpiData.winRate30d}
        todayTxs={kpiData.todayTxs}
        todayAmount={kpiData.todayAmount}
        journalStreak={kpiData.journalStreak}
        tradeInboxCount={kpiData.tradeInboxCount}
      />

      {(!hasTrades && confirmedEntries.length === 0) ? (
        <DashboardEmptyState />
      ) : (
        <>
          {/* Daily Bias Card - Full Width */}
          <DailyBiasCard 
            symbol="SOL"
            bias="bullish"
            confidence={75}
            bulletPoints={[
              "Market structure shows higher lows with strong momentum on intraday timeframes.",
              "Watching for pullbacks to re-enter long positions with tight risk management."
            ]}
            lastChecked={new Date()}
            onRefresh={handleRefreshBias}
            isRefreshing={isRefreshingBias}
            onViewAnalysis={() => navigate("/oracle")}
            onOpenChart={() => navigate("/chart")}
          />

          {/* Primary Cards Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3" data-testid="dashboard-primary-cards">
            <HoldingsCard />
            <LastTradesCard />
            <InsightCard isReady={trades.length >= 5} />
          </div>

          {/* Secondary Cards Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3" data-testid="dashboard-secondary-cards">
            <JournalSnapshotCard 
              totalEntries={journalData.totalEntries}
              thisWeekEntries={journalData.thisWeekEntries}
              lastEntryDate={journalData.lastEntryDate}
            />
            <AlertsSnapshotCard triggeredCount={triggeredAlerts} />
          </div>

          {/* Recent Entries Footer - Full Width */}
          <RecentEntriesCard 
            onViewJournal={handleViewJournal}
            onViewEntry={(id) => navigate(`/journal?entry=${id}`)}
          />
        </>
      )}

      {/* Show preview widgets when empty */}
      {(!hasTrades && confirmedEntries.length === 0) && (
        <div className="grid gap-4 md:grid-cols-2 opacity-60" data-testid="dashboard-preview-widgets">
          <DailyBiasCard 
            onRefresh={handleRefreshBias}
            isRefreshing={isRefreshingBias}
          />
          <HoldingsCard />
          <LastTradesCard />
          <InsightCard isReady={false} />
          <AlertsSnapshotCard triggeredCount={0} />
        </div>
      )}

      {/* Mobile FAB for quick actions */}
      <DashboardFab 
        onLogEntry={handleLogEntry}
        onCreateAlert={handleCreateAlert}
      />
    </div>
  );
}
