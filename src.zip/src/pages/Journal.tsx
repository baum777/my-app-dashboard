import { useEffect, useState } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { JournalEntryForm } from "@/components/journal/JournalEntryForm";
import { JournalView } from "@/features/journal/JournalView";
import { useJournalStore, setJournalWallet, addPendingEntry } from "@/features/journal/useJournalStore";
import { useJournalSync } from "@/hooks/useJournalSync";

export default function Journal() {
  const { pendingCount, archivedCount, confirmedCount } = useJournalStore();
  const { publicKey } = useWallet();
  const [sheetOpen, setSheetOpen] = useState(false);
  
  // E2E Mock Wallet
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const e2eWallet = (typeof window !== 'undefined' && (window as any).E2E_TEST_MODE) 
    ? { toBase58: () => 'e2e-test-wallet' } 
    : null;
  const effectivePublicKey = publicKey || e2eWallet;
  
  // Manage device secret for sync authentication
  const [secret] = useState(() => {
    try {
        let s = localStorage.getItem('sparkfined_device_secret');
        if (!s) {
            s = crypto.randomUUID();
            localStorage.setItem('sparkfined_device_secret', s);
        }
        return s;
    } catch {
        return "fallback-secret";
    }
  });

  // Update store context when wallet changes
  useEffect(() => {
    setJournalWallet(effectivePublicKey ? effectivePublicKey.toBase58() : null);
  }, [effectivePublicKey]);

  // Enable background sync
  useJournalSync(effectivePublicKey ? effectivePublicKey.toBase58() : null, secret);

  return (
    <div className="flex flex-col gap-6 p-4 sm:p-6" data-testid="page-journal">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Journal</h1>
          <p className="text-sm text-text-secondary">
            Auto-capture trades, add notes, and build self-awareness.
          </p>
        </div>
        
        <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
          <SheetTrigger asChild>
            <Button className="btn-primary gap-2" data-testid="journal-entry-trigger">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Entry</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto bg-surface border-l border-border-sf-subtle">
            <SheetHeader className="mb-6">
              <SheetTitle className="text-xl font-bold text-text-primary">Manual Entry</SheetTitle>
            </SheetHeader>
            <JournalEntryForm onSubmit={(data) => {
              addPendingEntry({
                token: { symbol: 'MANUAL', name: 'Journal Note' },
                createdAt: new Date().toISOString(),
                lastActivityAt: new Date().toISOString(),
                expiresAt: new Date(Date.now() + 86400000).toISOString(),
                position: { avgEntry: 0, sizeUsd: 0 },
                pnl: { unrealizedUsd: 0, realizedUsd: 0, pct: 0 },
                txs: [],
                status: 'active',
                notes: data.reasoning,
                tags: data.tags
              });
              setSheetOpen(false);
            }} />
          </SheetContent>
        </Sheet>
      </div>

      {/* Journal View with Segmented Control */}
      <JournalView
        confirmedCount={confirmedCount}
        pendingCount={pendingCount}
        archivedCount={archivedCount}
      />
    </div>
  );
}
