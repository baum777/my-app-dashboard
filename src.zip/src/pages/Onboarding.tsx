import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { ArrowRight, Sparkles, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/settings/ThemeToggle";
import { DataExportImport } from "@/components/settings/DataExportImport";

export default function OnboardingPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const totalSteps = 3;

  // Mark onboarding as complete when finishing
  const handleFinish = () => {
    localStorage.setItem("hasCompletedOnboarding", "true");
    navigate("/");
  };

  // Redirect if already completed
  useEffect(() => {
    if (localStorage.getItem("hasCompletedOnboarding") === "true") {
      navigate("/");
    }
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-root text-text-primary" data-testid="page-onboarding">
      <div className="w-full max-w-md space-y-8">
        
        {/* Progress */}
        <div className="flex justify-center gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div 
              key={s}
              className={`h-1.5 w-8 rounded-full transition-all duration-300 ${
                s <= step ? "bg-brand" : "bg-surface-elevated"
              }`} 
            />
          ))}
        </div>

        {/* Step 1: Welcome */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="text-center space-y-4">
              <div className="mx-auto h-16 w-16 bg-surface-elevated rounded-2xl flex items-center justify-center shadow-glow-brand border border-brand/20">
                <Sparkles className="h-8 w-8 text-brand" />
              </div>
              <h1 className="text-3xl font-bold tracking-tight">Welcome to Sparkfined</h1>
              <p className="text-text-secondary text-lg">
                Your AI-powered trading companion for journaling, analysis, and execution.
              </p>
            </div>
            
            <div className="pt-4">
              <Button 
                onClick={() => setStep(2)} 
                className="w-full btn-primary h-12 text-base"
                data-testid="onboarding-step1-next"
              >
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 2: Appearance */}
        {step === 2 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
             <div className="text-center space-y-2">
              <h2 className="text-2xl font-semibold">Choose your style</h2>
              <p className="text-text-secondary">
                Sparkfined is designed with a dark-mode-first approach for long trading sessions.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-surface border border-border-sf-subtle shadow-card-subtle">
              <ThemeToggle />
            </div>

            <div className="flex gap-3 pt-4">
              <Button 
                variant="ghost" 
                onClick={() => setStep(1)}
                className="flex-1 text-text-secondary hover:text-text-primary hover:bg-surface-hover"
              >
                Back
              </Button>
              <Button 
                onClick={() => setStep(3)} 
                className="flex-1 btn-primary"
                data-testid="onboarding-step2-next"
              >
                Next
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Data */}
        {step === 3 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
             <div className="text-center space-y-2">
              <h2 className="text-2xl font-semibold">Data Setup</h2>
              <p className="text-text-secondary">
                Start fresh or import your data from a backup. Your data is stored locally on your device.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-surface border border-border-sf-subtle shadow-card-subtle">
              <DataExportImport />
            </div>

            <div className="flex gap-3 pt-4">
              <Button 
                variant="ghost" 
                onClick={() => setStep(2)}
                className="flex-1 text-text-secondary hover:text-text-primary hover:bg-surface-hover"
              >
                Back
              </Button>
              <Button 
                onClick={handleFinish} 
                className="flex-1 btn-primary"
                data-testid="onboarding-finish"
              >
                Start Trading
                <Check className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

