import { z } from "zod";

// --- Base Types ---

export const tradeSchema = z.object({
  id: z.string(),
  asset: z.string(),
  direction: z.enum(["long", "short"]),
  entryPrice: z.string(),
  entryDate: z.string(),
  exitPrice: z.string().optional(),
  pnl: z.string().optional(),
  notes: z.string().optional(),
  tags: z.string().optional(),
  createdAt: z.string(),
});

export const capturedTransactionSchema = z.object({
  type: z.enum(["BUY", "SELL"]),
  time: z.string(),
  amount: z.number(),
  priceUsd: z.number(),
  valueUsd: z.number(),
});

export const tokenInfoSchema = z.object({
  symbol: z.string(),
  name: z.string(),
  mint: z.string().optional(),
});

export const positionSnapshotSchema = z.object({
  avgEntry: z.number(),
  sizeUsd: z.number(),
});

export const pnLInfoSchema = z.object({
  unrealizedUsd: z.number(),
  realizedUsd: z.number(),
  pct: z.number(),
});

// --- Extended Data ---

export const extendedDataSchema = z.object({
  marketContext: z.object({
    marketCap: z.number().optional(),
    marketCapCategory: z.enum(["micro", "small", "mid", "large"]).optional(),
    volume24h: z.number().optional(),
  }).optional(),
  technical: z.object({
    rsi: z.number().optional(),
    rsiCondition: z.enum(["oversold", "neutral", "overbought"]).optional(),
  }).optional(),
  onChain: z.object({
    holderCount: z.number().optional(),
    whaleConcentration: z.number().optional(),
    tokenAge: z.number().optional(),
    tokenMaturity: z.enum(["new", "established", "mature"]).optional(),
  }).optional(),
});

// --- Settings ---

export const extendedDataSettingsSchema = z.object({
  preset: z.enum(["minimal", "default", "maximum"]),
  marketContext: z.boolean(),
  technicalIndicators: z.boolean(),
  onChainMetrics: z.boolean(),
  customTimeframes: z.array(z.string()),
});

// --- Entries ---

export const pendingStatusSchema = z.enum(["active", "ready", "expiring"]);

export const autoCapturedEntrySchema = z.object({
  id: z.string(),
  wallet: z.string(),
  token: tokenInfoSchema,
  createdAt: z.string(),
  lastActivityAt: z.string(),
  expiresAt: z.string(),
  position: positionSnapshotSchema,
  pnl: pnLInfoSchema,
  txs: z.array(capturedTransactionSchema),
  extended: extendedDataSchema.optional(),
  
  // Derived fields (computed)
  isFullExit: z.boolean().optional(),
  timeLeftMs: z.number().optional(),
  status: pendingStatusSchema.optional(),
});

export const archiveReasonSchema = z.enum(["full_exit", "expired", "manual"]);

export const archivedEntrySchema = autoCapturedEntrySchema.extend({
  archivedAt: z.string(),
  archiveReason: archiveReasonSchema,
});

export const emotionTagSchema = z.enum(["fomo", "setup", "revenge", "fear", "greed"]);

export const entryEnrichmentSchema = z.object({
  emotion: emotionTagSchema.optional(),
  notes: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

export const confirmedEntrySchema = autoCapturedEntrySchema.extend({
  confirmedAt: z.string(),
  enrichment: entryEnrichmentSchema,
});

// Union of all persistable entries
export const persistableEntrySchema = z.union([
  autoCapturedEntrySchema.extend({ status: z.literal("active") }), // Explicit status for DB
  // For 'ready' and 'expiring', they are technically 'active' in DB mostly, 
  // but let's allow status field from PendingStatus to override if needed, 
  // though usually status is derived. 
  // However, the DB stores { ...entry, status: 'active'|'archived'|'confirmed' }.
  // The 'status' field in AutoCapturedEntry is derived (PendingStatus), but in DB it's used for Table partitioning.
  
  // Actually, looking at useJournalStore.ts:
  // persistEntry({...derived, status: 'active'});
  // persistEntry({...archivedEntry, status: 'archived'});
  // persistEntry({...confirmedEntry, status: 'confirmed'});
  
  // So we should define schemas for what goes into DB.
  autoCapturedEntrySchema.extend({ status: z.string() }), 
  archivedEntrySchema.extend({ status: z.string() }),
  confirmedEntrySchema.extend({ status: z.string() })
]);



