import { SettingsSection } from "@/components/settings";
import { MonitoringSettings } from "@/components/settings/MonitoringSettings";
import { TokenUsageSettings } from "@/components/settings/TokenUsageSettings";
import { RiskDefaultsSettings } from "@/components/settings/RiskDefaultsSettings";
import { AdvancedSettings } from "@/components/settings/AdvancedSettings";
import { FactoryReset } from "@/components/settings/FactoryReset";

export function SettingsSystem() {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
      {/* Monitoring */}
      <SettingsSection
        title="Monitoring"
        description="Data refresh and performance settings"
        data-testid="settings-section-monitoring"
      >
        <MonitoringSettings />
      </SettingsSection>

      {/* Token Usage */}
      <SettingsSection
        title="Token usage"
        description="Track your AI token consumption"
        data-testid="settings-section-tokens"
      >
        <TokenUsageSettings />
      </SettingsSection>

      {/* Risk Defaults */}
      <SettingsSection
        title="Risk defaults"
        description="Default risk parameters for trades"
        data-testid="settings-section-risk"
      >
        <RiskDefaultsSettings />
      </SettingsSection>

      {/* Advanced/Diagnostics */}
      <SettingsSection
        title="Advanced"
        description="Diagnostics and developer tools"
        data-testid="settings-section-advanced"
      >
        <AdvancedSettings />
      </SettingsSection>

      {/* Danger Zone */}
      <SettingsSection
        title="Danger zone"
        description="Irreversible actions"
        className="border-destructive/30"
        data-testid="settings-section-danger"
      >
        <FactoryReset />
      </SettingsSection>
    </div>
  );
}

