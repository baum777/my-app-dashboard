import { SettingsSection } from "@/components/settings";
import { ThemeToggle } from "@/components/settings/ThemeToggle";
import { ChartPrefsSettings } from "@/components/settings/ChartPrefsSettings";
import { NotificationsSettings } from "@/components/settings/NotificationsSettings";

export function SettingsGeneral() {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
      {/* Appearance */}
      <SettingsSection
        title="Appearance"
        description="Customize how the app looks"
        priority
        data-testid="settings-section-appearance"
      >
        <ThemeToggle />
      </SettingsSection>

      {/* Chart Preferences */}
      <SettingsSection
        title="Chart preferences"
        description="Default chart behavior and style"
        data-testid="settings-section-chart"
      >
        <ChartPrefsSettings />
      </SettingsSection>

      {/* Notifications */}
      <SettingsSection
        title="Notifications"
        description="Control alerts and reminders"
        data-testid="settings-section-notifications"
      >
        <NotificationsSettings />
      </SettingsSection>
    </div>
  );
}

