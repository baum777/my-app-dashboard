import { SettingsSection } from "@/components/settings";
import { ConnectedWalletsSettings } from "@/components/settings/ConnectedWalletsSettings";
import { DataExportImport } from "@/components/settings/DataExportImport";
import { JournalDataSettings } from "@/features/settings/JournalDataSettings";

export function SettingsData() {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
      {/* Connected Wallets */}
      <SettingsSection
        title="Connected wallets"
        description="Manage wallet connections for tracking"
        data-testid="settings-section-wallets"
      >
        <ConnectedWalletsSettings />
      </SettingsSection>

      {/* Journal Extended Data */}
      <SettingsSection
        title="Journal data"
        description="Configure auto-captured trade enrichments"
        data-testid="settings-section-journal"
      >
        <JournalDataSettings />
      </SettingsSection>

      {/* Backup & Restore */}
      <SettingsSection
        title="Backup & Restore"
        description="Export your data or restore from a backup"
        priority
        data-testid="settings-section-backup"
      >
        <DataExportImport />
      </SettingsSection>
    </div>
  );
}

