import { useState, useEffect, useCallback } from "react";
import { analyzeMarketDailyBias } from "@/lib/ai/dailyBiasService";
import { DailyBiasNarration, DailyBiasSignal } from "@/features/dailyBias/types";

export function useDailyBias(symbol: string = "SOL", timeframe: string = "15m") {
  const [signal, setSignal] = useState<DailyBiasSignal | null>(null);
  const [narration, setNarration] = useState<DailyBiasNarration | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const refresh = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await analyzeMarketDailyBias(symbol, timeframe);
      setSignal(result.signal);
      setNarration(result.narration);
      setLastUpdated(new Date(result.signal.computedAt));
    } catch (err) {
      console.error("Failed to fetch daily bias:", err);
      setError("Failed to load market analysis");
    } finally {
      setIsLoading(false);
    }
  }, [symbol, timeframe]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return {
    signal,
    narration,
    isLoading,
    error,
    lastUpdated,
    refresh,
  };
}

