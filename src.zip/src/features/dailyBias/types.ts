export type BiasDirection = "bull" | "bear" | "neutral";
export type MarketRegime = "trend" | "range" | "unknown";
export type ConfidenceTier = "low" | "medium" | "high";

export interface Candle {
  ts: number;      // epoch ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number; // optional
}

export interface MarketData {
  symbol: string;
  timeframe: string;     // e.g. "15m", "1h"
  candles: Candle[];     // ascending by ts
  lastPrice: number;     // usually last close
  source?: string;       // e.g. "DexScreener"
  fetchedAt: number;     // epoch ms
}

export interface DataQuality {
  ok: boolean;
  score: number;         // 0..1
  reasons: string[];     // why quality is low/high
  candleCount: number;
  expectedCount: number; // expected candles for window
  missingPct: number;    // 0..1
  outlierPct: number;    // 0..1
}

export interface BiasFeatures {
  low24h: number;
  high24h: number;
  rangePos24h: number;    // 0..1
  atrPct: number;         // 0..1 (e.g. 0.03 = 3%)
  trendSlope: number;     // normalized slope per candle
  structureScore: number; // -1..+1
  flowScore?: number;     // -1..+1 (optional)
  flowQuality?: "low" | "medium" | "high";
  regime: MarketRegime;
  quality: DataQuality;
}

export interface KeyLevels {
  support: number[];
  resistance: number[];
  invalidation?: number;
}

export interface Scenario {
  id: string;
  title: string;
  trigger: { type: "breakout" | "retest" | "breakdown"; level: number };
  confirmations: string[];
  targets: number[];
  invalidation: { type: "closeBelow" | "closeAbove"; level: number };
  notes?: string[];
}

export interface DailyBiasSignal {
  symbol: string;
  timeframe: string;
  computedAt: number;
  dataWindow: { fromTs: number; toTs: number };
  source?: string;

  bias: BiasDirection;
  confidence: number;        // 0..100
  confidenceTier: ConfidenceTier;

  features: BiasFeatures;
  keyLevels: KeyLevels;
  scenarios: Scenario[];
  reasons: string[];
}

export interface DailyBiasNarration {
  headline: string;
  bullets: string[];
  playbook: string[];
  disclaimer?: string;
}

