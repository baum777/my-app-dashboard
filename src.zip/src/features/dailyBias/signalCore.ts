import type { MarketData, DailyBiasSignal, BiasDirection, ConfidenceTier, KeyLevels, Scenario, BiasFeatures } from "./types";
import { buildFeatures, clamp } from "./heuristics";

export interface SignalCoreOptions {
  windowHours: number;     // default 24
  expectedCandles: number; // e.g. 96 for 15m over 24h
  nowTs?: number;          // inject for tests
}

function tierFromConfidence(conf: number): ConfidenceTier {
  if (conf >= 75) return "high";
  if (conf >= 55) return "medium";
  return "low";
}

function directionFromScores(structureScore: number, flowScore?: number): BiasDirection {
  const flow = typeof flowScore === "number" ? flowScore : 0;
  const combined = clamp(structureScore * 0.8 + flow * 0.2, -1, 1);
  if (combined >= 0.25) return "bull";
  if (combined <= -0.25) return "bear";
  return "neutral";
}

function computeConfidence(features: BiasFeatures): { confidence: number; reasons: string[] } {
  const reasons: string[] = [];

  const strength = Math.abs(features.structureScore);      // 0..1
  const strengthScore = strength * 55;                    // up to +55
  const regimeBonus = features.regime === "trend" ? 15 : features.regime === "range" ? 8 : 0;
  const qualityPenalty = (1 - features.quality.score) * 40; // up to -40

  const pos = features.rangePos24h;
  if (pos >= 0.70) reasons.push(`Price in upper 24h range (${Math.round(pos * 100)}%)`);
  else if (pos <= 0.30) reasons.push(`Price in lower 24h range (${Math.round(pos * 100)}%)`);
  else reasons.push(`Price near mid 24h range (${Math.round(pos * 100)}%)`);

  const slope = features.trendSlope;
  if (slope > 0.002) reasons.push("Upward slope detected");
  else if (slope < -0.002) reasons.push("Downward slope detected");
  else reasons.push("Flat slope / low directional drift");

  reasons.push(`Volatility (ATR) ~${(features.atrPct * 100).toFixed(1)}%`);
  if (!features.quality.ok) reasons.push(`Low data quality: ${features.quality.reasons.join("; ")}`);
  else reasons.push("Data quality OK");

  let conf = 20;
  conf += strengthScore;
  conf += regimeBonus;
  conf -= qualityPenalty;

  conf = clamp(conf, 0, 100);
  return { confidence: conf, reasons: reasons.slice(0, 6) };
}

function computeKeyLevels(features: BiasFeatures): KeyLevels {
  const low = features.low24h;
  const high = features.high24h;
  const mid = (low + high) / 2;

  const support = [low, mid].filter(x => x > 0);
  const resistance = [mid, high].filter(x => x > 0);

  return { support, resistance };
}

function buildScenarios(bias: BiasDirection, levels: KeyLevels, lastPrice: number, atrPct: number): Scenario[] {
  const atr = lastPrice * atrPct;
  const pad = Math.max(atr * 1.2, lastPrice * 0.005);

  const mid = levels.support[1] ?? levels.support[0] ?? lastPrice;
  const low = levels.support[0] ?? lastPrice;
  const high = levels.resistance[1] ?? levels.resistance[0] ?? lastPrice;

  if (bias === "bull") {
    const L = mid;
    return [
      {
        id: "bull_breakout",
        title: "Bullish breakout continuation",
        trigger: { type: "breakout", level: L },
        confirmations: ["closeAboveLevel", "rangeExpansion"],
        targets: [L + pad, Math.min(high, L + pad * 2)],
        invalidation: { type: "closeBelow", level: L - pad * 0.5 },
        notes: ["Prefer clean break + confirmation candle."],
      },
      {
        id: "bull_retest",
        title: "Bullish retest (pullback) entry",
        trigger: { type: "retest", level: L },
        confirmations: ["wickRejectionAtLevel", "higherLow"],
        targets: [L + pad, Math.min(high, L + pad * 2)],
        invalidation: { type: "closeBelow", level: L - pad * 0.6 },
      },
    ];
  }

  if (bias === "bear") {
    const L = mid;
    return [
      {
        id: "bear_breakdown",
        title: "Bearish breakdown continuation",
        trigger: { type: "breakdown", level: L },
        confirmations: ["closeBelowLevel", "rangeExpansion"],
        targets: [L - pad, Math.max(low, L - pad * 2)],
        invalidation: { type: "closeAbove", level: L + pad * 0.5 },
        notes: ["Avoid chasing into support; consider pullback entries."],
      },
      {
        id: "bear_retest",
        title: "Bearish retest (pullback) entry",
        trigger: { type: "retest", level: L },
        confirmations: ["wickRejectionAtLevel", "lowerHigh"],
        targets: [L - pad, Math.max(low, L - pad * 2)],
        invalidation: { type: "closeAbove", level: L + pad * 0.6 },
      },
    ];
  }

  return [
    {
      id: "neutral_range",
      title: "Range day (wait for confirmation)",
      trigger: { type: "breakout", level: mid },
      confirmations: ["closeOutsideRange", "rangeExpansion"],
      targets: [mid + pad, mid - pad].sort((a, b) => b - a),
      invalidation: { type: "closeBelow", level: mid - pad * 0.5 },
      notes: ["Neutral bias: reduce size, wait for clarity or mean reversion."],
    },
  ];
}

export function computeDailyBiasSignal(data: MarketData, opts: SignalCoreOptions): DailyBiasSignal {
  const now = opts.nowTs ?? Date.now();
  const window = data.candles.slice(-opts.expectedCandles);

  const fromTs = window[0]?.ts ?? now;
  const toTs = window[window.length - 1]?.ts ?? now;

  const features = buildFeatures(data, window, opts.expectedCandles);

  const keyLevels = computeKeyLevels(features);

  if (!features.quality.ok) {
    return {
      symbol: data.symbol,
      timeframe: data.timeframe,
      computedAt: now,
      dataWindow: { fromTs, toTs },
      source: data.source,

      bias: "neutral",
      confidence: Math.round(features.quality.score * 40),
      confidenceTier: "low",

      features,
      keyLevels,
      scenarios: buildScenarios("neutral", keyLevels, data.lastPrice, features.atrPct),
      reasons: ["Insufficient signal quality", ...features.quality.reasons].slice(0, 6),
    };
  }

  const bias = directionFromScores(features.structureScore, features.flowScore);
  const { confidence, reasons } = computeConfidence(features);

  const mid = (features.low24h + features.high24h) / 2;
  if (Number.isFinite(mid) && mid > 0) {
    if (bias === "bull") keyLevels.invalidation = mid * 0.995;
    else if (bias === "bear") keyLevels.invalidation = mid * 1.005;
    else keyLevels.invalidation = mid;
  }

  return {
    symbol: data.symbol,
    timeframe: data.timeframe,
    computedAt: now,
    dataWindow: { fromTs, toTs },
    source: data.source,

    bias,
    confidence: Math.round(confidence),
    confidenceTier: tierFromConfidence(confidence),

    features,
    keyLevels,
    scenarios: buildScenarios(bias, keyLevels, data.lastPrice, features.atrPct),
    reasons,
  };
}

