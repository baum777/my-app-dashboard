import type { DailyBiasSignal, DailyBiasNarration } from "./types";

function biasLabel(bias: DailyBiasSignal["bias"]): string {
  if (bias === "bull") return "Bullish";
  if (bias === "bear") return "Bearish";
  return "Neutral";
}

/**
 * Deterministic narration fallback (no LLM).
 * If you later add an LLM: it may ONLY transform text, never modify the signal.
 */
export function formatDailyBiasNarration(signal: DailyBiasSignal): DailyBiasNarration {
  const headline = `${biasLabel(signal.bias)} bias — ${signal.confidenceTier.toUpperCase()} (${signal.confidence}%)`;

  const bullets = [
    ...signal.reasons.slice(0, 5),
    signal.keyLevels.invalidation ? `Invalidation near ${signal.keyLevels.invalidation.toFixed(6)}` : "",
  ].filter(Boolean);

  const playbook = signal.scenarios.slice(0, 3).map(s => {
    const t1 = s.targets[0] ? s.targets[0].toFixed(6) : "n/a";
    const inv = s.invalidation.level.toFixed(6);
    return `${s.title}: trigger @ ${s.trigger.level.toFixed(6)} → target ${t1} | invalidation ${inv}`;
  });

  return {
    headline,
    bullets,
    playbook,
    disclaimer: "Market intel only — not financial advice. Confirm with your plan and risk rules.",
  };
}

