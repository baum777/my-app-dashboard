import type { Candle, MarketData, BiasFeatures, DataQuality, MarketRegime } from "./types";

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function safeDiv(a: number, b: number, fallback = 0): number {
  return b === 0 ? fallback : a / b;
}

export function mean(xs: number[]): number {
  if (!xs.length) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

export function percentile(sortedAsc: number[], p: number): number {
  if (!sortedAsc.length) return 0;
  const idx = clamp(p, 0, 1) * (sortedAsc.length - 1);
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  if (lo === hi) return sortedAsc[lo];
  const t = idx - lo;
  return sortedAsc[lo] * (1 - t) + sortedAsc[hi] * t;
}

export function computeATR(candles: Candle[], period = 14): number {
  if (candles.length < period + 1) return 0;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const prev = candles[i - 1];
    const tr = Math.max(
      c.high - c.low,
      Math.abs(c.high - prev.close),
      Math.abs(c.low - prev.close),
    );
    trs.push(tr);
  }
  return mean(trs.slice(-period));
}

export function computeTrendSlope(closes: number[]): number {
  const n = closes.length;
  if (n < 5) return 0;
  const xs = Array.from({ length: n }, (_, i) => i);
  const xMean = mean(xs);
  const yMean = mean(closes);

  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - xMean) * (closes[i] - yMean);
    den += (xs[i] - xMean) ** 2;
  }
  const slope = safeDiv(num, den, 0);
  return safeDiv(slope, yMean, 0); // normalized
}

export function detectRegime(trendSlope: number, atrPct: number): MarketRegime {
  const s = Math.abs(trendSlope);
  if (atrPct <= 0) return "unknown";
  if (s > atrPct * 0.25) return "trend";
  if (s < atrPct * 0.10) return "range";
  return "unknown";
}

export function computeDataQuality(data: MarketData, expectedCount: number): DataQuality {
  const candleCount = data.candles.length;
  const missing = clamp(1 - safeDiv(candleCount, expectedCount, 0), 0, 1);

  const ranges = data.candles.map(c => c.high - c.low).filter(x => Number.isFinite(x) && x >= 0);
  const rangesSorted = [...ranges].sort((a, b) => a - b);
  const med = percentile(rangesSorted, 0.5);
  const p95 = percentile(rangesSorted, 0.95);
  const outlier = med > 0 ? clamp((p95 / med - 1) / 10, 0, 1) : 0;

  const reasons: string[] = [];
  if (missing > 0.15) reasons.push(`Missing candles: ${(missing * 100).toFixed(0)}%`);
  if (outlier > 0.25) reasons.push("High range outliers (noisy candles)");
  const score = clamp(1 - (missing * 0.8 + outlier * 0.4), 0, 1);
  const ok = score >= 0.6;
  if (ok && reasons.length === 0) reasons.push("Data quality OK");

  return {
    ok,
    score,
    reasons,
    candleCount,
    expectedCount,
    missingPct: missing,
    outlierPct: outlier,
  };
}

export function compute24hRange(candles: Candle[]): { low24h: number; high24h: number } {
  let low = Number.POSITIVE_INFINITY;
  let high = Number.NEGATIVE_INFINITY;
  for (const c of candles) {
    if (c.low < low) low = c.low;
    if (c.high > high) high = c.high;
  }
  if (!Number.isFinite(low) || !Number.isFinite(high) || low === high) {
    return { low24h: 0, high24h: 0 };
  }
  return { low24h: low, high24h: high };
}

export function computeStructureScore(rangePos24h: number, trendSlope: number): number {
  const pos = clamp(rangePos24h, 0, 1);
  const posScore = (pos - 0.5) * 2; // -1..+1
  const slopeScore = clamp(trendSlope * 20, -1, 1);
  return clamp(posScore * 0.65 + slopeScore * 0.35, -1, 1);
}

export function buildFeatures(data: MarketData, windowCandles: Candle[], expectedCount: number): BiasFeatures {
  const { low24h, high24h } = compute24hRange(windowCandles);
  const range = high24h - low24h;
  const rangePos24h = range > 0 ? clamp((data.lastPrice - low24h) / range, 0, 1) : 0.5;

  const closes = windowCandles.map(c => c.close);
  const atr = computeATR(windowCandles, 14);
  const atrPct = data.lastPrice > 0 ? clamp(atr / data.lastPrice, 0, 1) : 0;

  const trendSlope = computeTrendSlope(closes);
  const structureScore = computeStructureScore(rangePos24h, trendSlope);
  const regime = detectRegime(trendSlope, atrPct);

  const quality = computeDataQuality({ ...data, candles: windowCandles }, expectedCount);

  return {
    low24h,
    high24h,
    rangePos24h,
    atrPct,
    trendSlope,
    structureScore,
    regime,
    quality,
  };
}

