import { db } from "@/features/journal/journal-db-schema";
import { eventBus, BusEvent, EventType } from "@/lib/events/EventBus";
import { QuestInstance, QuestTemplate } from "./types";
import { QUEST_TEMPLATES } from "./templates";
import { toast } from "@/hooks/use-toast";
import type { ConfirmedEntry } from "@/features/journal/types";

const XP_STORAGE_KEY = "sparkfined_user_xp";

class QuestEngine {
  private userId: string = "default-user";

  constructor() {
    this.subscribeToAllEvents();
  }

  setUserId(id: string) {
    this.userId = id;
  }

  private subscribeToAllEvents() {
    const allTriggers = new Set(QUEST_TEMPLATES.flatMap(t => t.triggerEvents));
    
    allTriggers.forEach(type => {
      eventBus.on(type as EventType, (event) => this.processEvent(event));
    });
  }

  async ensureDailyQuests() {
    const today = new Date();
    // Format YYYY-MM-DD in Europe/Berlin
    const timeKey = today.toLocaleDateString("en-CA", { timeZone: "Europe/Berlin" });
    
    // Check if we have quests for today
    const existing = await db.questInstances.where("timeKey").equals(timeKey).toArray();
    
    if (existing.length >= 3) {
      return; 
    }

    // Select 3 templates deterministically
    const seed = this.stringToHash(this.userId + timeKey);
    const selected = this.selectTemplates(seed, 3);
    
    // Create instances
    const instances: QuestInstance[] = selected.map(template => ({
      instanceId: crypto.randomUUID(),
      templateId: template.id,
      state: "active",
      startAt: Date.now(),
      endAt: new Date(today.setHours(23, 59, 59, 999)).getTime(),
      timeKey,
      progress: {
        current: 0,
        currents: {},
        events: []
      },
      seed,
      lastUpdatedAt: new Date().toISOString()
    }));
    
    await db.questInstances.bulkAdd(instances);
    console.log(`[QuestEngine] Generated ${instances.length} quests for ${timeKey}`);
    window.dispatchEvent(new Event("sparkfined-quests-update"));
  }

  private selectTemplates(seed: number, count: number): QuestTemplate[] {
    const dailyTemplates = QUEST_TEMPLATES.filter(t => t.timeframe === "daily");
    // Simple shuffle with seed
    const shuffled = [...dailyTemplates].sort((a, b) => {
      const hashA = this.stringToHash(a.id + seed);
      const hashB = this.stringToHash(b.id + seed);
      return hashA - hashB;
    });
    return shuffled.slice(0, count);
  }

  private async processEvent(event: BusEvent<EventType>) {
    // Load active quests
    const activeQuests = await db.questInstances
      .where("state")
      .equals("active")
      .toArray();

    for (const quest of activeQuests) {
      await this.applyEventToQuest(quest, event);
    }
  }

  private async applyEventToQuest(quest: QuestInstance, event: BusEvent<EventType>) {
    // Idempotency check
    if (quest.progress.events.includes(event.id)) return;

    const template = QUEST_TEMPLATES.find(t => t.id === quest.templateId);
    if (!template) return;

    if (!template.triggerEvents.includes(event.type)) return;

    // Filter check
    if (template.filter?.requires?.includes("emotion")) {
       const payload = event.payload as ConfirmedEntry;
       // ConfirmedEntry has enrichment with optional emotion field
       if (!payload.enrichment?.emotion) return;
    }

    // Update progress
    const newProgress = { ...quest.progress };
    let completed = false;

    if (template.progress.type === "counter") {
      newProgress.current += 1;
      if (template.progress.target && newProgress.current >= template.progress.target) {
        completed = true;
      }
    } else if (template.progress.type === "multiCounter") {
      if (!newProgress.currents) newProgress.currents = {};
      const currentVal = newProgress.currents[event.type] || 0;
      newProgress.currents[event.type] = currentVal + 1;
      
      // Check all targets
      const targets = template.progress.targets || {};
      const allMet = Object.entries(targets).every(([type, target]) => {
        return (newProgress.currents?.[type] || 0) >= target;
      });
      if (allMet) completed = true;
    }

    newProgress.events.push(event.id);

    // Save
    const updates: Partial<QuestInstance> = {
      progress: newProgress,
      lastUpdatedAt: new Date().toISOString()
    };

    if (completed) {
      updates.state = "completed";
      await this.awardReward(template.reward);
    }

    await db.questInstances.update(quest.instanceId, updates);
    window.dispatchEvent(new Event("sparkfined-quests-update"));
  }

  private async awardReward(reward: QuestTemplate["reward"]) {
    const currentXp = parseInt(localStorage.getItem(XP_STORAGE_KEY) || "0", 10);
    const newXp = currentXp + reward.xp;
    localStorage.setItem(XP_STORAGE_KEY, newXp.toString());
    
    console.log(`[QuestEngine] Awarded ${reward.xp} XP. Total: ${newXp}`);
    
    toast({
      title: "Quest Completed!",
      description: `You earned ${reward.xp} XP`,
      variant: "default"
    });
    
    // Trigger generic event to update UI? 
    // Or simpler: useQuestStore syncs from DB, but XP needs a signal.
    window.dispatchEvent(new Event("sparkfined-xp-update"));
  }

  private stringToHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return hash;
  }
}

export const questEngine = new QuestEngine();

