import { useState, useEffect } from "react";
import { db } from "@/features/journal/journal-db-schema";
import { QuestInstance } from "./types";
import { questEngine } from "./QuestEngine";

export function useQuestStore() {
  const [quests, setQuests] = useState<QuestInstance[]>([]);
  const [xp, setXp] = useState(0);

  const loadData = async () => {
    // XP
    const storedXp = localStorage.getItem("sparkfined_user_xp");
    setXp(storedXp ? parseInt(storedXp, 10) : 0);

    // Quests for today
    const todayKey = new Date().toLocaleDateString("en-CA", { timeZone: "Europe/Berlin" });
    const instances = await db.questInstances
      .where("timeKey")
      .equals(todayKey)
      .toArray();
    
    setQuests(instances);
  };

  useEffect(() => {
    loadData();

    const handleUpdate = () => loadData();
    window.addEventListener("sparkfined-xp-update", handleUpdate);
    window.addEventListener("sparkfined-quests-update", handleUpdate);
    
    return () => {
      window.removeEventListener("sparkfined-xp-update", handleUpdate);
      window.removeEventListener("sparkfined-quests-update", handleUpdate);
    };
  }, []);

  return {
    quests,
    xp,
    refresh: () => {
      questEngine.ensureDailyQuests().then(() => loadData());
    }
  };
}

