import { EventType } from "@/lib/events/EventBus";

export type QuestTimeframe = 'daily' | 'weekly' | 'lifetime';
export type QuestCategory = 'daily' | 'weekly' | 'lifetime';
export type Rank = 'degen' | 'seeker' | 'warrior' | 'master' | 'sage';

export interface QuestTemplate {
  id: string;
  title: string;
  category: QuestCategory;
  tags: string[];
  timeframe: QuestTimeframe;
  minRank: Rank;
  weight: number;
  cooldownDays: number;
  triggerEvents: EventType[];
  filter?: {
    requires?: string[]; // e.g. "emotion"
  };
  progress: {
    type: 'counter' | 'multiCounter';
    target?: number;
    targets?: Record<string, number>; // for multiCounter
  };
  reward: {
    xp: number;
    unlock?: string[];
  };
}

export type QuestState = 'active' | 'completed' | 'expired';

export interface QuestInstance {
  instanceId: string;
  templateId: string;
  state: QuestState;
  startAt: number; // timestamp
  endAt: number;   // timestamp
  timeKey: string; // "YYYY-MM-DD"
  progress: {
    current: number; // for counter
    currents?: Record<string, number>; // for multiCounter
    events: string[]; // List of eventIds applied (for idempotency)
  };
  seed: number; // deterministic selection seed
  lastUpdatedAt: string; // ISO string
}

