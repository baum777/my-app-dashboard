import { QuestTemplate } from "./types";

export const QUEST_TEMPLATES: QuestTemplate[] = [
  {
    id: "daily_journal_emotion_1",
    title: "Confirm 1 journal entry with emotion",
    category: "daily",
    tags: ["journal", "habit"],
    timeframe: "daily",
    minRank: "degen",
    weight: 10,
    cooldownDays: 1,
    triggerEvents: ["JOURNAL_ENTRY_CONFIRMED"],
    filter: {
      requires: ["emotion"]
    },
    progress: {
      type: "counter",
      target: 1
    },
    reward: {
      xp: 15
    }
  },
  {
    id: "daily_replay_practice_1",
    title: "Start a replay and place 1 practice trade",
    category: "daily",
    tags: ["replay", "practice"],
    timeframe: "daily",
    minRank: "degen",
    weight: 10,
    cooldownDays: 1,
    triggerEvents: ["REPLAY_STARTED", "REPLAY_TRADE_PLACED"],
    progress: {
      type: "multiCounter",
      targets: {
        "REPLAY_STARTED": 1,
        "REPLAY_TRADE_PLACED": 1
      }
    },
    reward: {
      xp: 20
    }
  },
  {
    id: "daily_alerts_ack_1",
    title: "Create 1 alert and acknowledge it",
    category: "daily",
    tags: ["alerts", "process"],
    timeframe: "daily",
    minRank: "degen",
    weight: 8,
    cooldownDays: 1,
    triggerEvents: ["ALERT_CREATED", "ALERT_ACKNOWLEDGED"],
    progress: {
      type: "multiCounter",
      targets: {
        "ALERT_CREATED": 1,
        "ALERT_ACKNOWLEDGED": 1
      }
    },
    reward: {
      xp: 15
    }
  },
  {
    id: "weekly_journal_3",
    title: "Confirm 3 journal entries this week",
    category: "weekly",
    tags: ["journal", "consistency"],
    timeframe: "weekly",
    minRank: "seeker",
    weight: 6,
    cooldownDays: 3,
    triggerEvents: ["JOURNAL_ENTRY_CONFIRMED"],
    progress: {
      type: "counter",
      target: 3
    },
    reward: {
      xp: 120
    }
  },
  {
    id: "weekly_replay_2",
    title: "Do 2 replays this week",
    category: "weekly",
    tags: ["replay", "skill"],
    timeframe: "weekly",
    minRank: "seeker",
    weight: 6,
    cooldownDays: 3,
    triggerEvents: ["REPLAY_STARTED"],
    progress: {
      type: "counter",
      target: 2
    },
    reward: {
      xp: 150
    }
  },
  {
    id: "lifetime_first_full_exit",
    title: "Log your first full exit",
    category: "lifetime",
    tags: ["journal", "milestone"],
    timeframe: "lifetime",
    minRank: "degen",
    weight: 1,
    cooldownDays: 0,
    triggerEvents: ["FULL_EXIT"],
    progress: {
      type: "counter",
      target: 1
    },
    reward: {
      xp: 250,
      unlock: ["badge_full_exit_first"]
    }
  }
];

