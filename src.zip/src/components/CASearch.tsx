import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Clock, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const HISTORY_KEY = "ca-search-history";
const MAX_HISTORY = 5;

export function CASearch() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Load history on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(HISTORY_KEY);
      if (stored) {
        setHistory(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Failed to parse search history", e);
    }
  }, []);

  // Click outside handler
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowHistory(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = (term: string) => {
    if (!term.trim()) return;

    // Update history
    const newHistory = [term, ...history.filter((h) => h !== term)].slice(0, MAX_HISTORY);
    setHistory(newHistory);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));

    // Navigate
    navigate(`/chart?token=${encodeURIComponent(term)}`);
    setShowHistory(false);
    // Optional: clear query or keep it? Keeping it usually better for context.
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch(query);
    }
  };

  const removeHistoryItem = (e: React.MouseEvent, item: string) => {
    e.stopPropagation();
    const newHistory = history.filter((h) => h !== item);
    setHistory(newHistory);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
  };

  return (
    <div className="relative w-full max-w-md" ref={wrapperRef}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-tertiary" />
        <Input
          type="text"
          placeholder="Search CA or Token..."
          className="h-9 w-full rounded-xl bg-surface-subtle pl-9 pr-4 text-sm text-text-primary border-border-sf-moderate focus:border-brand focus:ring-brand/40"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setShowHistory(true)}
          onKeyDown={handleKeyDown}
          data-testid="header-ca-search"
        />
      </div>

      {/* History Dropdown */}
      {showHistory && history.length > 0 && (
        <div className="absolute top-full mt-2 w-full overflow-hidden rounded-xl border border-border-sf-subtle bg-surface-elevated shadow-xl z-50 animate-in fade-in zoom-in-95 duration-100">
          <div className="px-3 py-2 text-[10px] font-medium uppercase tracking-wider text-text-tertiary">
            Recent Searches
          </div>
          <ul>
            {history.map((item) => (
              <li key={item}>
                <button
                  className="flex w-full items-center justify-between px-3 py-2 text-sm text-text-secondary hover:bg-surface-hover hover:text-text-primary transition-colors"
                  onClick={() => {
                    setQuery(item);
                    handleSearch(item);
                  }}
                >
                  <div className="flex items-center gap-2">
                    <Clock className="h-3.5 w-3.5 text-text-tertiary" />
                    <span>{item}</span>
                  </div>
                  <div
                    role="button"
                    tabIndex={0}
                    className="rounded p-1 hover:bg-surface-subtle hover:text-text-primary text-text-tertiary"
                    onClick={(e) => removeHistoryItem(e, item)}
                  >
                    <X className="h-3 w-3" />
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

