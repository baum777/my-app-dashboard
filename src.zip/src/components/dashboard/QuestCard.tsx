import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Circle } from "lucide-react";
import { useQuestStore } from "@/features/quests/useQuestStore";
import { QUEST_TEMPLATES } from "@/features/quests/templates";
import { cn } from "@/lib/utils";

export function QuestCard() {
  const { quests, xp } = useQuestStore();

  if (quests.length === 0) return null;

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-sm font-medium">Daily Quests</CardTitle>
        <Badge variant="secondary" className="font-mono text-xs">
          {xp} XP
        </Badge>
      </CardHeader>
      <CardContent className="grid gap-4">
        {quests.map(quest => {
          const template = QUEST_TEMPLATES.find(t => t.id === quest.templateId);
          if (!template) return null;

          const isCompleted = quest.state === "completed";
          
          let percent = 0;
          let label = "";
          
          if (template.progress.type === "counter") {
            const current = quest.progress.current;
            const target = template.progress.target || 1;
            percent = Math.min(100, (current / target) * 100);
            label = `${current}/${target}`;
          } else if (template.progress.type === "multiCounter") {
            const targets = template.progress.targets || {};
            const totalSteps = Object.keys(targets).length;
            const currents = quest.progress.currents || {};
            let stepsDone = 0;
            Object.entries(targets).forEach(([key, target]) => {
                if ((currents[key] || 0) >= target) stepsDone++;
            });
            percent = (stepsDone / totalSteps) * 100;
            label = `${stepsDone}/${totalSteps}`;
          }

          return (
            <div key={quest.instanceId} className="flex items-center space-x-4">
              {isCompleted ? (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              ) : (
                <Circle className="w-5 h-5 text-muted-foreground" />
              )}
              <div className="flex-1 space-y-1">
                <p className={cn("text-sm font-medium leading-none", isCompleted && "line-through text-muted-foreground")}>
                  {template.title}
                </p>
                <div className="flex items-center gap-2">
                   <Progress value={percent} className="h-2 w-full" />
                   <span className="text-xs text-muted-foreground tabular-nums">{label}</span>
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

