export function sanitizePII(text: string): string {
  let sanitized = text;

  // Replace emails
  sanitized = sanitized.replace(/\b[\w.-]+@[\w.-]+\.\w{2,4}\b/g, '[REDACTED-EMAIL]');
  
  // Replace simple phone numbers (stub regex)
  // Boundaries \b are tricky with + or (, so we use specific patterns
  // German mobile: 0176-12345678, +49 176 ...
  sanitized = sanitized.replace(/(?:\b|(?<=\s))(?:\+?49|0)[ -]?1[5-7][0-9][ -]?[0-9]{7,8}\b/g, '[REDACTED-PHONE]');
  // US: (555) 123-4567, 555-123-4567
  sanitized = sanitized.replace(/(?:\b|(?<=\s))\(?555\)?[- ]?123[- ]?4567\b/g, '[REDACTED-PHONE]');
  
  // Replace Credit Cards (stub)
  // 4242 4242 4242 4242
  // Use \b to ensure we don't match inside long strings like Solana addresses
  sanitized = sanitized.replace(/\b(?:\d{4}[- ]?){3}\d{4}\b/g, '[REDACTED-CC]');
  
  // Replace SSN (stub)
  // 123-45-6789
  sanitized = sanitized.replace(/\b\d{3}-\d{2}-\d{4}\b/g, '[REDACTED-SSN]');

  return sanitized;
}
