export function detectPIITypes(text: string): string[] {
  const pii: string[] = [];
  
  // Email
  if (/\b[\w.-]+@[\w.-]+\.\w{2,4}\b/.test(text)) pii.push('email');
  
  // Phone (Stub)
  if (/(?:\+?49|0)[ -]?1[5-7][0-9]/.test(text) || /\(?555\)?[- ]?123/.test(text)) pii.push('phone');

  // Credit Card (Stub)
  if (/\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}/.test(text)) pii.push('creditcard');

  // SSN (Stub)
  if (/\d{3}-\d{2}-\d{4}/.test(text)) pii.push('ssn');

  return pii;
}
