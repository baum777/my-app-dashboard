import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface SettingsState {
  openaiApiKey: string | null;
  setOpenaiApiKey: (key: string | null) => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      openaiApiKey: null,
      setOpenaiApiKey: (key) => set({ openaiApiKey: key }),
    }),
    {
      name: 'sparkfined-settings',
    }
  )
);

